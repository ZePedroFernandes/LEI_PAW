# Ficha Prática 3

## basicDomSample

Projeto de suporte ao segundo exercício da ficha prática

## validationSample

Projeto de suporte ao terceiro exercício da ficha prática

## toDoSample

Projeto de suporte ao quarto exercício da ficha prática

## XMLHttpRequestSampe

Projeto de suporte ao quinto exercício da ficha prática
