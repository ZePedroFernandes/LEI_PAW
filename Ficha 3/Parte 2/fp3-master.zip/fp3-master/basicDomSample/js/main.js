

document.addEventListener("load", function(ev){
    document.getElementById("myForm").addEventListener("submit", function(ev){
        ev.preventDefault();
        return false;
    })
    
    document.getElementById("submeter").addEventListener("click", function (ev) {
        readFromData();
    }
)
})

function readFromData(ev) {
    ev.preventDefault();
    // ToDo
    return false;
}